package producerconsumer;

public interface MessageHolder {
  String getMessage();
  void putMessage(String message);  
}
