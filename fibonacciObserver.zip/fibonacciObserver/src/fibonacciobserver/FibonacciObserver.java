package ex2;

public interface FibonacciObserver {
    void dataReady(long tal);
}
